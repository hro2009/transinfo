/**
 * Created by Hro on 08.12.2015.
 */
/**
 * Created by Hro on 08.12.2015.
 */
$(document).ready(function(){

    $('.bxslider').bxSlider({
        minSlides: 4,
        maxSlides: 4,
        slideWidth: 360,
        slideMargin: 10,
        moveSlides: 1,
        auto:true
    });

})