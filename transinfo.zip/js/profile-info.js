$(document).ready(function(){

    $('#diagram-id-1').circleDiagram({
        "percent": "33%",
        "size": "100",
        "borderWidth": "20",
        "bgFill": "#e2e2e2",
        "frFill": "#06c",
        "textSize": "20",
        "textColor": "#3d88ba"
    });
        $('#diagram-id-2').circleDiagram({
            "percent": "88%",
            "size": "100",
            "borderWidth": "20",
            "bgFill": "#e2e2e2",
            "frFill": "#06c",
            "textSize": "20",
            "textColor": "#3d88ba"
        });
            $('#diagram-id-3').circleDiagram({
                "percent": "77%",
                "size": "100",
                "borderWidth": "20",
                "bgFill": "#e2e2e2",
                "frFill": "#06c",
                "textSize": "20",
                "textColor": "#3d88ba"
            });
                $('#diagram-id-4').circleDiagram({
                    "percent": "66%",
                    "size": "100",
                    "borderWidth": "20",
                    "bgFill": "#e2e2e2",
                    "frFill": "#06c",
                    "textSize": "20",
                    "textColor": "#3d88ba"
                });
                    $('#diagram-id-5').circleDiagram({
                        "percent": "55%",
                        "size": "100",
                        "borderWidth": "20",
                        "bgFill": "#e2e2e2",
                        "frFill": "#06c",
                        "textSize": "20",
                        "textColor": "#3d88ba"
                    });


})